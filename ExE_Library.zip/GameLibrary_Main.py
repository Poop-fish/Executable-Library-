import PySimpleGUI as sg
import threading , traceback , os ,shutil , subprocess , json , webbrowser 
from time import strftime

from Layouts import create_layout , show_help 

sg.theme("NeonGreen1")

# >> Function to load games from a JSON file << 
def load_games():
    if os.path.exists("games.json"):
        with open("games.json", "r") as f:
            return json.load(f)
    return {}
# >> Function to save the games to a JSON file << 
def save_games():
    with open("games.json", "w") as f:
        json.dump(games, f)

# >> ThreadFunction << 
def run_game_in_thread(game_name):
    try:
        game_path = games.get(game_name)
        if os.path.isfile(game_path) and game_path.endswith('.exe'):
            game_dir = os.path.dirname(game_path)
            subprocess.Popen(game_path, cwd=game_dir)  # \\ Launch the .exe file with the correct working directory \\ 
        else:
            sg.popup_error("Selected file is not a valid executable.", title="Error")
    except Exception as e:
        sg.popup_error(f"Error: {e}\n\n{traceback.format_exc()}", title="Error", background_color="black", text_color="white")

# >> Function to update time in real-time << 
def update_time():
    while True:
        current_time = strftime('%Y-%m-%d %I:%M:%S %p')
        window['TIME_DISPLAY'].update(current_time) 
        sg.time.sleep(1)

# >> Function to open Google search in browser << 
def open_google_search(query):
    if query:
        search_url = f"https://www.google.com/search?q={query}"
        webbrowser.open(search_url)  # \\ Opens the URL in the default web browser \\ 

# >> Updated add_new_game function << 
def add_new_game(game_name, game_path, assets_folder):
    if game_name and game_path and os.path.isfile(game_path):
        try:
            game_dir = os.path.join("games", game_name)
            if not os.path.exists(game_dir):
                os.makedirs(game_dir)

            shutil.copy(game_path, game_dir)
            
            if assets_folder and os.path.exists(assets_folder):
                assets_dest = os.path.join(game_dir, "assets")
                if os.path.exists(assets_dest):
                    shutil.rmtree(assets_dest)
                shutil.copytree(assets_folder, assets_dest)

            games[game_name] = os.path.join(game_dir, os.path.basename(game_path))
            save_games()  # Save games to the file

            window.write_event_value('GAME_ADDED', game_name)
            sg.popup("Game added successfully!", title="Success")
        except Exception as e:
            window.write_event_value('ERROR', f"Error adding the game: {e}")

# \\ Load saved games when the program starts \\ 
games = load_games()
# \\ Create the layout using the imported function \\ 
layout = create_layout(games)
window = sg.Window("ExE Library", layout, element_justification="left", finalize=True, resizable=True, background_color="#2e2d2d", icon="FaceLogo.ico", size=(525, 600))
threading.Thread(target=update_time, daemon=True).start()
window.set_cursor('icon')
# \\ Update game list with saved games \\ 
window['GAME_LIST'].update(values=list(games.keys()))

# \\ Main Loop \\ 
while True:
    event, values = window.read()

    if event == sg.WINDOW_CLOSED or event == "Exit":
        break

    if event == "Play Game":
        selected_game = values["GAME_LIST"]
        if selected_game:
            threading.Thread(target=run_game_in_thread, args=(selected_game[0],), daemon=True).start()
        else:
            sg.popup_error("Please select a game!", title="Error", background_color="black", text_color="lime")

    if event == "ADD_GAME":
        game_name = values["GAME_NAME"]
        game_path = values["GAME_PATH"]
        assets_folder = values["ASSETS_PATH"]
        add_new_game(game_name, game_path, assets_folder)

    if event == 'GAME_ADDED':
        window['GAME_LIST'].update(values=list(games.keys()))  

    if event == 'ERROR':
        sg.popup_error(values[event], title="Error", background_color="black", text_color="white")
    if event == 'Help': 
            show_help()
    if event == "SEARCH_GOOGLE":
        search_query = values["SEARCH_QUERY"]
        open_google_search(search_query)

window.close()
