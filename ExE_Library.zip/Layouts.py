import PySimpleGUI as sg

def create_layout(games):
    layout = [
        [sg.Menu([['Help', ['Help']]], tearoff=False)],
        [sg.Text("Executable--Library", font=("Helvetica", 20), justification="center", expand_x=True)],
        [sg.HorizontalSeparator()],
        [sg.Text("Date & Time:", font=("Helvetica", 12)), sg.Text("", key="TIME_DISPLAY", size=(20, 1), font=("Helvetica", 12), text_color="lime", justification="center", expand_x=True)],
        [sg.HorizontalSeparator()],
        [sg.Text("Google Search:", font=("Helvetica", 12), justification="center", expand_x=True)],
        [sg.InputText("", key="SEARCH_QUERY", size=(30, 1)), sg.Button("Search", key="SEARCH_GOOGLE", size=(10, 1), button_color=("black", "lime"))],
        [sg.HorizontalSeparator()],
        [sg.Text("Library:", font=("Helvetica", 12), justification="center", expand_x=True)],
        [sg.Listbox(values=list(games.keys()), size=(40, 10), key="GAME_LIST", select_mode=sg.LISTBOX_SELECT_MODE_SINGLE, font=("Helvetica", 10), justification="center", expand_x=True)],
        [sg.Button("Play Game", size=(10, 1), button_color=("black", "red"))],
        [sg.HorizontalSeparator()],
        [sg.Text("Upload Your Executable", font=("Helvetica", 14), text_color="darkgreen", justification="center", expand_x=True)],
        [sg.Text("Game Name:", size=(10, 1)), sg.InputText("", key="GAME_NAME", size=(30, 1))],
        [sg.Text("Executable Path:", size=(15, 1)), sg.InputText("", key="GAME_PATH", size=(30, 1)), sg.FileBrowse(file_types=[("Executable Files", "*.exe")])],
        [sg.Text("Assets Folder Path:", size=(15, 1)), sg.InputText("", key="ASSETS_PATH", size=(30, 1)), sg.FolderBrowse()],
        [sg.Button("Add Game", key="ADD_GAME", size=(10, 1), button_color=("black", "red"))],
    ]

    return [[sg.Column(layout, element_justification="center", expand_x=True)]]

def show_help():
    help_text = """
    Welcome !

    1. To add your game or software ExE file:
       - Browse and Add the executable path, and assets folder path.
       - Click "Add Game" once paths are selected .
    
       It should now appear in the Library Frame.
       
       Click the text that was added and then click "Play Game."
       This should run the ExE file; just give it a minute to boot up.
       
       Removing ExE files:
       All you have to do is delete the JSON file to remove all the ExE files you uploaded
       to the Application.
    """
    sg.popup("Help", help_text)
